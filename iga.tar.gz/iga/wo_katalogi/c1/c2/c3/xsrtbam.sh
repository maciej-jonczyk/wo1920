#! /bin/sh
/home/sekwoja/bin/bin/samtools sort -@ 22 -o s68_iiif2.sorted.bam s68_iiif2.bam -O bam -T temp
echo powt 2. sorted
/home/sekwoja/bin/bin/samtools sort -@ 22 -o s68_iiif3.sorted.bam s68_iiif3.bam -O bam -T temp
echo powt 3. sorted
/home/sekwoja/bin/bin/samtools index s68_iiif2.sorted.bam
echo powt 2. sorted
/home/sekwoja/bin/bin/samtools index s68_iiif3.sorted.bam
echo powt 3. sorted KONIEC
