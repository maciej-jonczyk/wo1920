  595  grep masked eb152710_T001podz > x
  596  sed 's/masked//;s/ //g' x > x2
  597  mv x2 Zm00001eb152710_T001A-C
  598  grep 'Zm00001eb175950_T001' ../agpv5/Zm-B73-REFERENCE-NAM-5.0_Zm00001eb.1.sorted.gff3 | grep exon | cut -f1,4,5 -d"	" | sed 's/chr//;s/	/:/;s/	/-/' > eb175950_exons
  599  cat eb175950_exons
  600  tr '\n' ' ' < eb175950_exons | sed 's/ / -L /g'> x
  601  featherpad x
  602  ~/bin/gatk-4.2.5.0/gatk FastaAlternateReferenceMaker -R v5_4gatk.fa -O eb175950_exons.fa -L 4:53715253-53715722 -L 4:53716123-53716698 -L 4:53716855-53717388 -V /media/nev/ANTIX-LIVE/vcf_pl/pl4.recode.sorted.vcf --snp-mask /media/nev/ANTIX-LIVE/vcf_pl/pl4.recode.sorted.vcf --snp-mask-priority true
  603  sed '/>/d' eb175950_exons.fa > x
  604  grep masked eb175950_T001podz > x
  605  sed 's/masked//;s/ //g' x > 
  606  mv x2 Zm00001eb175950_T001A-B
  607  grep 'Zm00001eb247820_T001' ../agpv5/Zm-B73-REFERENCE-NAM-5.0_Zm00001eb.1.sorted.gff3 | grep exon | cut -f1,4,5 -d"	" | sed 's/chr//;s/	/:/;s/	/-/' > eb247820_exons
 
